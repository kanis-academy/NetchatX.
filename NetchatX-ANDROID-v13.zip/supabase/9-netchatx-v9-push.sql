-- NetchatX v9 : notifications push (Firebase). A executer APRES le fichier 8.
create table if not exists public.device_tokens(
  token text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text not null default 'android',
  updated_at timestamptz not null default now());
create index if not exists device_tokens_user_idx on public.device_tokens(user_id);
alter table public.device_tokens enable row level security;
-- Aucune policy : l'application passe uniquement par les deux fonctions ci-dessous,
-- et la fonction d'envoi lit la table avec la cle service_role (cote serveur).

create or replace function public.register_device_token(p_token text) returns void
language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null or coalesce(trim(p_token),'')='' then raise exception 'Invalide'; end if;
  insert into public.device_tokens(token,user_id,updated_at) values(p_token,auth.uid(),now())
  on conflict (token) do update set user_id=excluded.user_id, updated_at=now();
end $$;
create or replace function public.unregister_device_token(p_token text) returns void
language sql security definer set search_path=public as $$
  delete from public.device_tokens where token=p_token and user_id=auth.uid();
$$;
revoke all on function public.register_device_token(text), public.unregister_device_token(text) from public, anon;
grant execute on function public.register_device_token(text), public.unregister_device_token(text) to authenticated;
