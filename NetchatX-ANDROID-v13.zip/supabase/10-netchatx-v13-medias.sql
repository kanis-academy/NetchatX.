-- NetchatX v13 : fichiers des discussions (vocaux, photos, vidéos) lisibles par les utilisateurs connectés
insert into storage.buckets (id,name,public) values ('chat-media','chat-media',false) on conflict (id) do nothing;
drop policy if exists "chat-media lecture" on storage.objects;
drop policy if exists "chat-media envoi" on storage.objects;
create policy "chat-media lecture" on storage.objects for select to authenticated using (bucket_id='chat-media');
create policy "chat-media envoi"   on storage.objects for insert to authenticated with check (bucket_id='chat-media');
