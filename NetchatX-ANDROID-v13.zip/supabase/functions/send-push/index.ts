// Edge Function « send-push » : envoie une notification Firebase (FCM v1) a chaque nouveau message / appel.
// Appelee par un Database Webhook (tables messages et calls, evenement INSERT).
// Secret requis : FCM_SERVICE_ACCOUNT (contenu JSON de la cle de compte de service Firebase).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const sa = JSON.parse(Deno.env.get("FCM_SERVICE_ACCOUNT") ?? "{}");
const ok = () => new Response("ok");

const b64u = (b: ArrayBuffer | string) => {
  const u = typeof b === "string" ? new TextEncoder().encode(b) : new Uint8Array(b);
  let s = ""; u.forEach((c) => (s += String.fromCharCode(c)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
let cache: { t: string; exp: number } | null = null;
async function accessToken(): Promise<string> {
  if (cache && cache.exp > Date.now() + 60000) return cache.t;
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const c = b64u(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
  const pem = String(sa.private_key).replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (x) => x.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(h + "." + c));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=" + encodeURIComponent("urn:ietf:params:oauth:grant-type:jwt-bearer") + "&assertion=" + h + "." + c + "." + b64u(sig),
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("FCM auth: " + JSON.stringify(j));
  cache = { t: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 };
  return cache.t;
}

const typeLabel: Record<string, string> = { image: "📷 Photo", video: "🎥 Vidéo", audio: "🎤 Message vocal", file: "📎 Fichier" };

Deno.serve(async (req) => {
  try {
    const p = await req.json();
    const rec = p.record;
    if (p.type !== "INSERT" || !rec) return ok();
    let targets: string[] = [], sender = "", title = "", body = "", convId: string | null = null, group = false;

    if (p.table === "messages") {
      if (rec.message_type === "system" || rec.deleted_at) return ok();
      sender = rec.sender_id; convId = rec.conversation_id;
      const { data: conv } = await sb.from("conversations").select("kind,title").eq("id", convId).single();
      const { data: mem } = await sb.from("conversation_members").select("user_id").eq("conversation_id", convId).neq("user_id", sender);
      targets = (mem ?? []).map((m) => m.user_id);
      group = conv?.kind === "group";
      const { data: pr } = await sb.from("profiles").select("display_name").eq("id", sender).maybeSingle();
      const name = pr?.display_name ?? "Nouveau message";
      title = group ? `${name} • ${conv?.title ?? "Groupe"}` : name;
      body = typeLabel[rec.message_type] ?? String(rec.body ?? "");
    } else if (p.table === "calls") {
      sender = rec.caller_id; convId = rec.conversation_id; targets = [rec.callee_id];
      const { data: pr } = await sb.from("profiles").select("display_name").eq("id", sender).maybeSingle();
      title = pr?.display_name ?? "NetchatX"; body = "T’a appelé(e)";
    } else return ok();

    if (!targets.length) return ok();

    // contacts bloques (dans un sens ou dans l'autre) : pas de notification
    if (!group) {
      const { data: bl } = await sb.from("blocks").select("blocker_id,blocked_id")
        .or(`and(blocker_id.eq.${sender},blocked_id.in.(${targets.join(",")})),and(blocked_id.eq.${sender},blocker_id.in.(${targets.join(",")}))`);
      const bad = new Set((bl ?? []).flatMap((b) => [b.blocker_id, b.blocked_id]));
      targets = targets.filter((t) => !bad.has(t));
    }
    // reglages de notification de chaque utilisateur
    const { data: st } = await sb.from("user_settings").select("user_id,message_notifications,group_notifications,call_notifications").in("user_id", targets);
    const off = new Set((st ?? []).filter((s) =>
      p.table === "calls" ? s.call_notifications === false : (s.message_notifications === false || (group && s.group_notifications === false))
    ).map((s) => s.user_id));
    targets = targets.filter((t) => !off.has(t));
    if (!targets.length) return ok();

    const { data: toks } = await sb.from("device_tokens").select("token").in("user_id", targets);
    if (!toks?.length) return ok();
    const at = await accessToken();
    await Promise.all(toks.map(async ({ token }) => {
      const r = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
        method: "POST", headers: { Authorization: "Bearer " + at, "Content-Type": "application/json" },
        body: JSON.stringify({ message: { token, notification: { title, body: body.slice(0, 140) }, data: { conversation_id: String(convId ?? "") }, android: { priority: "HIGH", notification: { sound: "default" } } } }),
      });
      if (r.status === 404 || r.status === 400) {
        const t = await r.text();
        if (/UNREGISTERED|NOT_FOUND|INVALID_ARGUMENT/.test(t)) await sb.from("device_tokens").delete().eq("token", token);
      }
    }));
    return ok();
  } catch (e) {
    console.error(String(e));
    return new Response("error", { status: 500 });
  }
});
