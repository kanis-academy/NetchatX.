-- NetchatX v4 : groupes, statuts, historique des appels. A executer APRES netchatx-v3.sql.

-- GROUPES
create or replace function public.create_group(p_title text, p_members uuid[]) returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid; m uuid;
begin
  if auth.uid() is null or coalesce(trim(p_title),'')='' then raise exception 'Nom du groupe requis'; end if;
  if coalesce(array_length(p_members,1),0)<1 then raise exception 'Choisis au moins un membre'; end if;
  insert into conversations(kind,title,created_by) values('group',trim(p_title),auth.uid()) returning id into cid;
  insert into conversation_members(conversation_id,user_id,role) values(cid,auth.uid(),'owner');
  foreach m in array p_members loop
    if m<>auth.uid() then insert into conversation_members(conversation_id,user_id,role) values(cid,m,'member') on conflict do nothing; end if;
  end loop;
  return cid;
end $$;
revoke all on function public.create_group(text,uuid[]) from public, anon;
grant execute on function public.create_group(text,uuid[]) to authenticated;

-- STATUTS (24 h) : visibles par soi-meme et par les personnes avec qui on a une discussion
create table if not exists public.statuses(
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('text','image')),
  body text, bg text, media_url text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '24 hours');
alter table public.statuses enable row level security;
create or replace function public.shares_conv(p uuid) returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from conversation_members a join conversation_members b on a.conversation_id=b.conversation_id where a.user_id=auth.uid() and b.user_id=p) $$;
revoke all on function public.shares_conv(uuid) from public, anon;
grant execute on function public.shares_conv(uuid) to authenticated;
drop policy if exists st_sel on public.statuses; create policy st_sel on public.statuses for select to authenticated using (expires_at>now() and (user_id=auth.uid() or public.shares_conv(user_id)));
drop policy if exists st_ins on public.statuses; create policy st_ins on public.statuses for insert to authenticated with check (user_id=auth.uid());
drop policy if exists st_del on public.statuses; create policy st_del on public.statuses for delete to authenticated using (user_id=auth.uid());
insert into storage.buckets (id,name,public) values ('statuses','statuses',true) on conflict (id) do nothing;
drop policy if exists "Statut ajout propre" on storage.objects;
create policy "Statut ajout propre" on storage.objects for insert to authenticated with check (bucket_id='statuses' and (storage.foldername(name))[1]=auth.uid()::text);

-- HISTORIQUE DES APPELS
create table if not exists public.calls(
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid references public.conversations(id) on delete set null,
  caller_id uuid not null references auth.users(id) on delete cascade,
  callee_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'calling',
  started_at timestamptz not null default now(),
  ended_at timestamptz);
alter table public.calls enable row level security;
drop policy if exists call_sel on public.calls; create policy call_sel on public.calls for select to authenticated using (caller_id=auth.uid() or callee_id=auth.uid());
drop policy if exists call_ins on public.calls; create policy call_ins on public.calls for insert to authenticated with check (caller_id=auth.uid());
drop policy if exists call_upd on public.calls; create policy call_upd on public.calls for update to authenticated using (caller_id=auth.uid() or callee_id=auth.uid());
