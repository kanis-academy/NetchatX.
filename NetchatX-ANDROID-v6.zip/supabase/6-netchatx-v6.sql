-- NetchatX v6 : page publique du profil (lien partagé /u/<id>)
-- Ne renvoie QUE le nom, le « à propos » et la photo. Rien d'autre n'est exposé.
create or replace function public.public_profile(p_id uuid)
returns table(display_name text, about text, avatar_url text)
language sql stable security definer set search_path = public as $$
  select p.display_name, p.about, p.avatar_url from public.profiles p where p.id = p_id;
$$;
revoke all on function public.public_profile(uuid) from public;
grant execute on function public.public_profile(uuid) to anon, authenticated;
