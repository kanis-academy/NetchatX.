-- NetchatX v3 : a executer APRES netchatx-v2.sql (SQL Editor > Run).
-- Photos de profil (dossier public, chaque utilisateur n'ecrit que dans son propre dossier)
insert into storage.buckets (id, name, public) values ('avatars','avatars',true) on conflict (id) do nothing;
drop policy if exists "Avatar ajout propre" on storage.objects;
create policy "Avatar ajout propre" on storage.objects for insert to authenticated with check (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Avatar modif propre" on storage.objects;
create policy "Avatar modif propre" on storage.objects for update to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Avatar suppression propre" on storage.objects;
create policy "Avatar suppression propre" on storage.objects for delete to authenticated using (bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);

-- Suppression de son propre compte (profil, messages et appartenances partent en cascade)
create or replace function public.delete_my_account() returns void language plpgsql security definer set search_path=public,auth as $$
begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  delete from auth.users where id=auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;
