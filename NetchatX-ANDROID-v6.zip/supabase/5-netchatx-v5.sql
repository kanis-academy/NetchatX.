-- NetchatX v5 : statuts vidéo
alter table public.statuses drop constraint if exists statuses_kind_check;
alter table public.statuses add constraint statuses_kind_check check (kind in ('text','image','video'));
