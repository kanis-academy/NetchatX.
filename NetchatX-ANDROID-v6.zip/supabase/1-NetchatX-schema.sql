-- NetchatX / Supabase initial schema
-- Run this file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Utilisateur',
  phone text unique,
  avatar_url text,
  about text not null default '',
  role text not null default 'buyer' check (role in ('buyer','reseller','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles add column if not exists role text not null default 'buyer';
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('buyer','reseller','admin'));

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  kind text not null default 'direct' check (kind in ('direct','group')),
  title text,
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','member')),
  joined_at timestamptz not null default now(),
  last_read_at timestamptz,
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null default '',
  message_type text not null default 'text' check (message_type in ('text','image','video','audio','file','system')),
  attachment_path text,
  reply_to uuid references public.messages(id) on delete set null,
  created_at timestamptz not null default now(),
  edited_at timestamptz,
  deleted_at timestamptz
);

-- Role hardening: users may choose buyer/reseller at signup, but cannot self-promote to admin.
-- An administrator can grant admin from the Supabase SQL Editor (service role context).
create or replace function public.guard_profile_role()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if TG_OP = 'INSERT' then
    if new.role = 'admin' and coalesce(auth.role(), '') <> 'service_role' then
      raise exception 'Admin role can only be granted by a trusted administrator';
    end if;
  elsif new.role is distinct from old.role then
    if coalesce(auth.role(), '') <> 'service_role' then
      raise exception 'Profile role cannot be changed by the account owner';
    end if;
  end if;
  return new;
end;
$$;
drop trigger if exists profiles_guard_role on public.profiles;
create trigger profiles_guard_role before insert or update on public.profiles
for each row execute function public.guard_profile_role();

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index if not exists conversation_members_user_idx on public.conversation_members(user_id);

create or replace function public.is_conversation_member(cid uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.conversation_members cm where cm.conversation_id = cid and cm.user_id = auth.uid()); $$;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Profiles visible to authenticated users" on public.profiles;
create policy "Profiles visible to authenticated users" on public.profiles for select to authenticated using (true);
drop policy if exists "Users create own profile" on public.profiles;
create policy "Users create own profile" on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

drop policy if exists "Members can view conversations" on public.conversations;
create policy "Members can view conversations" on public.conversations for select to authenticated using (public.is_conversation_member(id));
drop policy if exists "Authenticated users create conversations" on public.conversations;
create policy "Authenticated users create conversations" on public.conversations for insert to authenticated with check (created_by = auth.uid());
drop policy if exists "Members can view memberships" on public.conversation_members;
create policy "Members can view memberships" on public.conversation_members for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists "Conversation creator adds initial members" on public.conversation_members;
create policy "Conversation creator adds initial members" on public.conversation_members for insert to authenticated with check (
  user_id = auth.uid() or exists (select 1 from public.conversations c where c.id = conversation_id and c.created_by = auth.uid())
);
drop policy if exists "Members can update own membership" on public.conversation_members;
create policy "Members can update own membership" on public.conversation_members for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "Members can read messages" on public.messages;
create policy "Members can read messages" on public.messages for select to authenticated using (public.is_conversation_member(conversation_id));
drop policy if exists "Members can send as themselves" on public.messages;
create policy "Members can send as themselves" on public.messages for insert to authenticated with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id));
drop policy if exists "Authors can edit own messages" on public.messages;
create policy "Authors can edit own messages" on public.messages for update to authenticated using (sender_id = auth.uid()) with check (sender_id = auth.uid());

-- Private bucket. Access policies restrict files to members of the matching conversation folder.
insert into storage.buckets (id, name, public) values ('chat-media','chat-media',false) on conflict (id) do nothing;
drop policy if exists "Conversation members read chat media" on storage.objects;
create policy "Conversation members read chat media" on storage.objects for select to authenticated using (
  bucket_id = 'chat-media' and public.is_conversation_member((storage.foldername(name))[1]::uuid)
);
drop policy if exists "Conversation members upload chat media" on storage.objects;
create policy "Conversation members upload chat media" on storage.objects for insert to authenticated with check (
  bucket_id = 'chat-media' and public.is_conversation_member((storage.foldername(name))[1]::uuid)
);

-- Enable Realtime for messages. If already present, ignore duplicate membership.
do $$ begin alter publication supabase_realtime add table public.messages; exception when duplicate_object then null; when undefined_object then null; end $$;
