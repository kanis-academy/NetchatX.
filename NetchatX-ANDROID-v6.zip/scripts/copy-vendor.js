const fs=require("fs"),path=require("path");
const src=path.join(__dirname,"..","node_modules","@supabase","supabase-js","dist","umd","supabase.js");
const to=path.join(__dirname,"..","www","js","vendor");
if(!fs.existsSync(src)){console.error("supabase.js introuvable : lance « npm install ».");process.exit(1);}
fs.mkdirSync(to,{recursive:true});fs.copyFileSync(src,path.join(to,"supabase.js"));console.log("supabase.js copié.");
