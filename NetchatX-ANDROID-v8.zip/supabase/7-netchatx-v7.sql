-- NetchatX v7 : bloquer un contact + supprimer / vider une discussion (comme WhatsApp)

-- 1) Contacts bloqués
create table if not exists public.blocks(
  blocker_id uuid not null references auth.users(id) on delete cascade,
  blocked_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id));
alter table public.blocks enable row level security;
drop policy if exists blk_sel on public.blocks; create policy blk_sel on public.blocks for select to authenticated using (blocker_id = auth.uid());
drop policy if exists blk_ins on public.blocks; create policy blk_ins on public.blocks for insert to authenticated with check (blocker_id = auth.uid() and blocked_id <> auth.uid());
drop policy if exists blk_del on public.blocks; create policy blk_del on public.blocks for delete to authenticated using (blocker_id = auth.uid());

create or replace function public.blocked_pair(a uuid, b uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a));
$$;
grant execute on function public.blocked_pair(uuid, uuid) to authenticated;

create or replace function public.blocked_in_conv(cid uuid) returns boolean language sql stable security definer set search_path = public as $$
  select exists(
    select 1 from public.conversations c
    join public.conversation_members m on m.conversation_id = c.id and m.user_id <> auth.uid()
    where c.id = cid and c.kind = 'direct' and public.blocked_pair(auth.uid(), m.user_id));
$$;
grant execute on function public.blocked_in_conv(uuid) to authenticated;

-- un contact bloqué (dans un sens ou dans l'autre) ne peut plus envoyer de message ni appeler
drop policy if exists "Members can send as themselves" on public.messages;
create policy "Members can send as themselves" on public.messages for insert to authenticated
  with check (sender_id = auth.uid() and public.is_conversation_member(conversation_id) and not public.blocked_in_conv(conversation_id));
drop policy if exists call_ins on public.calls;
create policy call_ins on public.calls for insert to authenticated
  with check (caller_id = auth.uid() and not public.blocked_pair(caller_id, callee_id));

-- 2) Supprimer / vider une discussion (pour moi seulement)
alter table public.conversation_members add column if not exists cleared_at timestamptz;
alter table public.conversation_members add column if not exists chat_deleted boolean not null default false;
