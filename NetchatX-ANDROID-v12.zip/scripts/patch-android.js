// Après « cap add android » : permissions caméra/micro (appels vidéo) + icône NetchatX.
const fs=require("fs"),path=require("path");
const root=path.join(__dirname,"..");
const man=path.join(root,"android","app","src","main","AndroidManifest.xml");
if(!fs.existsSync(man)){console.error("android/ introuvable : lance « npx cap add android » d'abord.");process.exit(1);}
let s=fs.readFileSync(man,"utf8");
const perms=["INTERNET","ACCESS_NETWORK_STATE","CAMERA","RECORD_AUDIO","MODIFY_AUDIO_SETTINGS","ACCESS_FINE_LOCATION","ACCESS_COARSE_LOCATION","POST_NOTIFICATIONS"];
let add="";
for(const p of perms)if(!s.includes('android.permission.'+p+'"'))add+=`    <uses-permission android:name="android.permission.${p}" />\n`;
for(const f of ["camera","microphone"])if(!s.includes('android.hardware.'+f))add+=`    <uses-feature android:name="android.hardware.${f}" android:required="false" />\n`;
s=s.replace("<application",add+"    <application");
fs.writeFileSync(man,s);
const res=path.join(root,"android","app","src","main","res"),src=path.join(root,"resources","android-icons");
for(const d of fs.readdirSync(src)){const to=path.join(res,d);fs.mkdirSync(to,{recursive:true});for(const f of fs.readdirSync(path.join(src,d)))fs.copyFileSync(path.join(src,d,f),path.join(to,f));}
const any=path.join(res,"mipmap-anydpi-v26");fs.mkdirSync(any,{recursive:true});
const xml=`<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/netchatx_icon_bg"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n`;
fs.writeFileSync(path.join(any,"ic_launcher.xml"),xml);fs.writeFileSync(path.join(any,"ic_launcher_round.xml"),xml);
const vals=path.join(res,"values");fs.mkdirSync(vals,{recursive:true});
fs.writeFileSync(path.join(vals,"netchatx_icon.xml"),`<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="netchatx_icon_bg">#FFFFFF</color>\n</resources>\n`);
// Firebase (notifications push) : fichier google-services.json + plugin Gradle
const gs=path.join(root,"firebase","google-services.json");
if(!fs.existsSync(gs)){console.error("firebase/google-services.json introuvable.");process.exit(1);}
if(!fs.readFileSync(gs,"utf8").includes('"com.netchatx.app"')){console.error("google-services.json ne contient pas com.netchatx.app.");process.exit(1);}
fs.copyFileSync(gs,path.join(root,"android","app","google-services.json"));
const rb=path.join(root,"android","build.gradle"),ab=path.join(root,"android","app","build.gradle");
let r=fs.readFileSync(rb,"utf8");
if(!r.includes("com.google.gms:google-services")){r=r.replace(/(\n\s*)(classpath\s+['"]com\.android\.tools\.build:gradle[^\n]*)/,"$1$2$1classpath 'com.google.gms:google-services:4.4.2'");fs.writeFileSync(rb,r);}
let a=fs.readFileSync(ab,"utf8");
if(!a.includes("com.google.gms.google-services")){a+="\napply plugin: 'com.google.gms.google-services'\n";fs.writeFileSync(ab,a);}
console.log("Permissions, icône et Firebase NetchatX installés.");
