-- NetchatX v2 : a executer APRES NetchatX-schema.sql (SQL Editor > Run).
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,display_name) values(new.id,coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'),''),split_part(new.email,'@',1),'Utilisateur')) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
insert into public.profiles(id,display_name) select u.id,coalesce(nullif(trim(u.raw_user_meta_data->>'display_name'),''),split_part(u.email,'@',1)) from auth.users u on conflict (id) do nothing;

-- Les numeros de telephone ne sont plus lisibles par les autres utilisateurs
revoke select on public.profiles from anon, authenticated;
grant select (id,display_name,avatar_url,about,role,created_at,updated_at) on public.profiles to authenticated;

-- Creation (ou recuperation) d'une conversation directe en une seule fois
create or replace function public.start_direct(p_other uuid) returns uuid language plpgsql security definer set search_path=public as $$
declare cid uuid;
begin
  if auth.uid() is null or p_other is null or p_other=auth.uid() then raise exception 'Invalide'; end if;
  select c.id into cid from conversations c where c.kind='direct'
    and exists(select 1 from conversation_members a where a.conversation_id=c.id and a.user_id=auth.uid())
    and exists(select 1 from conversation_members b where b.conversation_id=c.id and b.user_id=p_other) limit 1;
  if cid is null then
    insert into conversations(kind,created_by) values('direct',auth.uid()) returning id into cid;
    insert into conversation_members(conversation_id,user_id,role) values(cid,auth.uid(),'owner'),(cid,p_other,'member');
  end if;
  return cid;
end $$;
revoke all on function public.start_direct(uuid) from public, anon;
grant execute on function public.start_direct(uuid) to authenticated;


-- Durcissement des droits : appliquer aussi ces restrictions sur les bases deja installees.
drop policy if exists "Conversation creator adds initial members" on public.conversation_members;
drop policy if exists "Only conversation creator adds members" on public.conversation_members;
create policy "Only conversation creator adds members" on public.conversation_members for insert to authenticated with check (
  exists (select 1 from public.conversations c where c.id = conversation_id and c.created_by = auth.uid())
);
drop policy if exists "Members can update own membership" on public.conversation_members;
drop policy if exists "Members can update own read receipt" on public.conversation_members;
create policy "Members can update own read receipt" on public.conversation_members for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke update on public.conversation_members from authenticated;
grant update (last_read_at) on public.conversation_members to authenticated;
drop policy if exists "Authors can edit own messages" on public.messages;
revoke update, delete on public.messages from authenticated;
