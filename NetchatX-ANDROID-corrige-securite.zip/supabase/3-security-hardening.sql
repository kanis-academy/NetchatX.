-- NetchatX : correctifs de securite a appliquer aux bases deja installees.
-- A executer dans Supabase Dashboard > SQL Editor avec un compte proprietaire.

-- Empeche un utilisateur de s'ajouter lui-meme a une conversation dont il n'est pas createur.
drop policy if exists "Conversation creator adds initial members" on public.conversation_members;
drop policy if exists "Only conversation creator adds members" on public.conversation_members;
create policy "Only conversation creator adds members"
on public.conversation_members for insert to authenticated
with check (
  exists (
    select 1 from public.conversations c
    where c.id = conversation_id and c.created_by = auth.uid()
  )
);

-- Le client ne peut changer que son horodatage de derniere lecture,
-- pas son user_id, son role ou le conversation_id.
drop policy if exists "Members can update own membership" on public.conversation_members;
drop policy if exists "Members can update own read receipt" on public.conversation_members;
create policy "Members can update own read receipt"
on public.conversation_members for update to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());
revoke update on public.conversation_members from authenticated;
grant update (last_read_at) on public.conversation_members to authenticated;

-- Aucune fonction d'edition/suppression de message n'est encore exposee dans l'app.
-- On ferme donc ces droits cote API cliente jusqu'a l'ajout d'une fonction controlee.
drop policy if exists "Authors can edit own messages" on public.messages;
revoke update, delete on public.messages from authenticated;
